import tracemalloc
import time

def fib_memo(n, mem={}):
    time.start_time = time.time()
    tracemalloc.start()

    if n in mem:
        return mem[n]
    if n <=1:
        mem[n] = n
    else:
        mem[n] = fib_memo(n-1, mem) + fib_memo(n-2, mem)
    return mem[n]

print(fib_memo(21))
#(CodeLucky, 2025)

current, peak = tracemalloc.get_traced_memory()
print(f"\n--- Execution Time: {(time.time() - time.start_time) * 1000:.3f} miliseconds ---")
print(f"--- Memory Usage: {peak:.2f} bytes ---")




#-------------------------------
#References

#CodeLucky (2025). Fibonacci Sequence: Classic Dynamic Programming Example with Python - CodeLucky. [online] CodeLucky. Available at: https://codelucky.com/fibonacci-sequence/ [Accessed 23 Jan. 2026].