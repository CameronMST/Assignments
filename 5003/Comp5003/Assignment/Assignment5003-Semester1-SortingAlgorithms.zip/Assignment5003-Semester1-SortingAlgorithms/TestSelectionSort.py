import random
import time
import tracemalloc
my_list = [random.randint(1,100) for _ in range(10)]


def selection_sort(my_list, equality='+'):
    time.start_time = time.time()
    tracemalloc.start()
    for iter in range(0, len(my_list)-1):
        min = iter
        for i in range(iter + 1, len(my_list)):
            
            if equality == '-':
                if my_list[i] > my_list[min]:
                    min = i
            #Descending - Placed at top for default Ascending, if anyother option is entered.
            else:
                if my_list[i] < my_list[min]:
                    min = i
            #Descending
        my_list[iter], my_list[min] = my_list[min], my_list[iter]
    return my_list

print(selection_sort(my_list)) # (W3Schools, n.d)
current, peak = tracemalloc.get_traced_memory()
print(f"\n--- Execution Time: {(time.time() - time.start_time) * 1000:.3f} miliseconds ---")
print(f"--- Memory Usage: {peak:.2f} bytes ---")


#Reference
#W3schools, (n.d.). DSA Selection Sort. [online] Available at: https://www.w3schools.com/dsa/dsa_algo_selectionsort.php.[Accessed 23/01/2026].